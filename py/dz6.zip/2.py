mx, mn = int(input()), int(input())
mas = [i for i in range(12)]
print([i for i in mas if i <= mx and i >= mn])