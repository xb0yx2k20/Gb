import num_handler as nh

def user_choice():
    print("\n 1. Add contact"
          "\n 2. Delete contact"
          "\n 3. Export contacts in file"
          "\n 4. Import contacts from file"
          "\n 5. Stop programm"
          "\n\n Choose number \n"
          )
    nh.get_num()