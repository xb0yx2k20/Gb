from termcolor import colored
import user_interface as ui

print(colored("\n Hi! I am your phone book created by Raul. Lets i show you what can i do!", "blue"))
ui.user_choice()
