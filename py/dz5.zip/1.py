res = [i for i in input().split() if "абв" not in i]
for x in res:
    print(x, end=' ')
